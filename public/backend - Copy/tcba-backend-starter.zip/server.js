const express = require('express');
const session = require('express-session');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = 5000;

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(session({
  secret: 'supersecret',
  resave: false,
  saveUninitialized: false
}));

// Database setup
const db = new sqlite3.Database(path.join(__dirname, 'database.sqlite'));

// Run schema.sql if first run
const fs = require('fs');
const schemaPath = path.join(__dirname, 'schema.sql');
if (fs.existsSync(schemaPath)) {
  const schema = fs.readFileSync(schemaPath, 'utf8');
  db.exec(schema);
}

// Routes
app.use('/auth', require('./routes/auth')(db));
app.use('/members', require('./routes/members')(db));
app.use('/wallet', require('./routes/wallet')(db));
app.use('/automation', require('./routes/automation')(db));

app.get('/', (req, res) => {
  res.json({ status: 'TCBA API running' });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));