const express = require('express');
const bcrypt = require('bcrypt');

module.exports = (db) => {
  const router = express.Router();

  router.post('/signup', async (req, res) => {
    const { name, email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Missing fields' });

    const hash = await bcrypt.hash(password, 10);
    db.run('INSERT INTO members (name, email, password) VALUES (?, ?, ?)',
      [name, email, hash], function (err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID, name, email });
      });
  });

  router.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.get('SELECT * FROM members WHERE email = ?', [email], async (err, row) => {
      if (err || !row) return res.status(400).json({ error: 'Invalid login' });
      const match = await bcrypt.compare(password, row.password);
      if (!match) return res.status(400).json({ error: 'Invalid login' });
      req.session.user = { id: row.id, email: row.email };
      res.json({ message: 'Logged in', user: req.session.user });
    });
  });

  return router;
};