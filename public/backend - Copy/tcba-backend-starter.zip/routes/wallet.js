const express = require('express');

module.exports = (db) => {
  const router = express.Router();

  router.post('/add', (req, res) => {
    const { member_id, amount, note } = req.body;
    db.run('INSERT INTO tcba_wallet_transactions (member_id, amount, note) VALUES (?, ?, ?)',
      [member_id, amount, note], function (err) {
        if (err) return res.status(500).json({ error: err.message });
        db.run('INSERT INTO tcba_wallet (member_id, balance) VALUES (?, ?) ON CONFLICT(member_id) DO UPDATE SET balance = balance + ?',
          [member_id, amount, amount]);
        res.json({ id: this.lastID, member_id, amount, note });
      });
  });

  return router;
};