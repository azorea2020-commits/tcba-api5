const express = require('express');

module.exports = (db) => {
  const router = express.Router();

  router.post('/toggle', (req, res) => {
    const { key, value, actor, note } = req.body;
    db.get('SELECT value FROM system_settings WHERE key = ?', [key], (err, row) => {
      const oldValue = row ? row.value : null;
      db.run('INSERT INTO system_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = ?, updated_at = CURRENT_TIMESTAMP',
        [key, value, value]);
      db.run('INSERT INTO automation_audit (setting_key, old_value, new_value, actor, note) VALUES (?, ?, ?, ?, ?)',
        [key, oldValue, value, actor, note]);
      res.json({ key, oldValue, newValue: value });
    });
  });

  return router;
};