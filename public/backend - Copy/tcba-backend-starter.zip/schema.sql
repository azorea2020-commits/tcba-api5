-- Members table
CREATE TABLE IF NOT EXISTS members (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Officers table
CREATE TABLE IF NOT EXISTS officers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id INTEGER,
  role TEXT NOT NULL,
  acting BOOLEAN DEFAULT 0,
  FOREIGN KEY (member_id) REFERENCES members(id)
);

-- Wallet table
CREATE TABLE IF NOT EXISTS tcba_wallet (
  member_id INTEGER PRIMARY KEY,
  balance REAL DEFAULT 0,
  FOREIGN KEY (member_id) REFERENCES members(id)
);

-- Wallet transactions
CREATE TABLE IF NOT EXISTS tcba_wallet_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id INTEGER,
  amount REAL,
  note TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (member_id) REFERENCES members(id)
);

-- Automation settings
CREATE TABLE IF NOT EXISTS system_settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Automation audit
CREATE TABLE IF NOT EXISTS automation_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  setting_key TEXT,
  old_value TEXT,
  new_value TEXT,
  actor TEXT,
  note TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);